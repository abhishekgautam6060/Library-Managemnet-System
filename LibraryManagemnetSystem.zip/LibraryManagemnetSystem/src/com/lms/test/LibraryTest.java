package com.lms.test;


import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.lms.Book;
import com.lms.Library;


public class LibraryTest {
    private Library library;

    @BeforeEach
    public void setUp() {
        library = new Library();
    }

    @Test
    public void testAddBook() {
        Book book = new Book("Title1", "Author1", "ISBN1", "Genre1", 2021, "Dept1", true);
        library.addBook(book);
        assertEquals(1, library.listAllBooks().size());
    }

    @Test
    public void testRemoveBook() {
        Book book = new Book("Title2", "Author2", "ISBN2", "Genre2", 2022, "Dept2", true);
        library.addBook(book);
        library.removeBook("ISBN2");
        assertEquals(0, library.listAllBooks().size());
    }

    @Test
    public void testFindBookByTitle() {
        Book book = new Book("UniqueTitle", "Author3", "ISBN3", "Genre3", 2023, "Dept3", true);
        library.addBook(book);
        List<Book> foundBooks = library.findBookByTitle("UniqueTitle");
        assertEquals(1, foundBooks.size());
        assertEquals("ISBN3", foundBooks.get(0).getISBN());
    }

    @Test
    public void testFindBookByAuthor() {
        Book book = new Book("Title4", "UniqueAuthor", "ISBN4", "Genre4", 2024, "Dept4", true);
        library.addBook(book);
        List<Book> foundBooks = library.findBookByAuthor("UniqueAuthor");
        assertEquals(1, foundBooks.size());
        assertEquals("ISBN4", foundBooks.get(0).getISBN());
    }

    @Test
    public void testListAvailableBooks() {
        Book book1 = new Book("Title5", "Author5", "ISBN5", "Genre5", 2025, "Dept5", true);
        Book book2 = new Book("Title6", "Author6", "ISBN6", "Genre6", 2026, "Dept6", false);
        library.addBook(book1);
        library.addBook(book2);
        List<Book> availableBooks = library.listAvailableBooks();
        assertEquals(1, availableBooks.size());
        assertEquals("ISBN5", availableBooks.get(0).getISBN());
    }
}
