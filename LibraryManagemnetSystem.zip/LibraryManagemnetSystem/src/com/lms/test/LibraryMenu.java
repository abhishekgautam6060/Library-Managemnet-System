package com.lms.test;

import java.util.Scanner;

import com.lms.Book;
import com.lms.Library;

public class LibraryMenu {
    private Library library;
    private Scanner scanner;

    public LibraryMenu(Library library) {
        this.library = library;
        this.scanner = new Scanner(System.in);
    }

    public void displayMenu() {
        while (true) {
            System.out.println("Library Menu:");
            System.out.println("1. Add Book");
            System.out.println("2. Remove Book");
            System.out.println("3. Find Book by Title");
            System.out.println("4. Find Book by Author");
            System.out.println("5. List All Books");
            System.out.println("6. List Available Books");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addBook();
                    break;
                case 2:
                    removeBook();
                    break;
                case 3:
                    findBookByTitle();
                    break;
                case 4:
                    findBookByAuthor();
                    break;
                case 5:
                    listAllBooks();
                    break;
                case 6:
                    listAvailableBooks();
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void addBook() {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        System.out.print("Enter ISBN: ");
        String ISBN = scanner.nextLine();
        System.out.print("Enter genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter publication year: ");
        int publicationYear = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter department: ");
        String department = scanner.nextLine();
        System.out.print("Is the book available (true/false)? ");
        boolean isAvailable = scanner.nextBoolean();
        scanner.nextLine();

        Book book = new Book(title, author, ISBN, genre, publicationYear, department, isAvailable);
        library.addBook(book);
    }

    private void removeBook() {
        System.out.print("Enter ISBN of the book to remove: ");
        String ISBN = scanner.nextLine();
        library.removeBook(ISBN);
    }

    private void findBookByTitle() {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        library.findBookByTitle(title).forEach(System.out::println);
    }

    private void findBookByAuthor() {
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        library.findBookByAuthor(author).forEach(System.out::println);
    }

    private void listAllBooks() {
        library.listAllBooks().forEach(System.out::println);
    }

    private void listAvailableBooks() {
        library.listAvailableBooks().forEach(System.out::println);
    }
}

