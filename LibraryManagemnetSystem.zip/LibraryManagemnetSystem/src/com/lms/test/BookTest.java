package com.lms.test;



import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.lms.Book;

public class BookTest {
    @Test
    public void testBookCreation() {
        Book book = new Book("Title", "Author", "1234567890", "Genre", 2020, "Department", true);
        assertEquals("Title", book.getTitle());
        assertEquals("Author", book.getAuthor());
        assertEquals("1234567890", book.getISBN());
        assertEquals("Genre", book.getGenre());
        assertEquals(2020, book.getPublicationYear());
        assertEquals("Department", book.getDepartment());
        assertTrue(book.isAvailable());
    }
}

