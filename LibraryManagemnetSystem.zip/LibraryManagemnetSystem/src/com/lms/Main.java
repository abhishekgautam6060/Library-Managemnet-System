package com.lms;

import com.lms.test.LibraryMenu;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        LibraryMenu libraryMenu = new LibraryMenu(library);
        libraryMenu.displayMenu();
    }
}

